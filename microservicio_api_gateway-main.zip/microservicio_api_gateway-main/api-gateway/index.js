const express = require('express');
const proxy = require('express-http-proxy');
const cors = require('cors'); // Agregar esta línea

const app = express();
const port = 3000;

const usersServiceUrl = 'http://localhost:3001';
const productsServiceUrl = 'http://localhost:3002';

// Configurar CORS - AGREGAR ESTO
app.use(cors({
    origin: ['http://127.0.0.1:5500', 'http://localhost:5500', 'http://localhost:3000'],
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Proxy para usuarios
app.use('/usuarios', proxy(usersServiceUrl, {
    proxyReqOptDecorator: (proxyReqOpts, srcReq) => {
        proxyReqOpts.headers = { ...srcReq.headers };
        return proxyReqOpts;
    },
    proxyReqPathResolver: (req) => req.originalUrl
}));

// Proxy para productos
app.use('/productos', proxy(productsServiceUrl, {
    proxyReqOptDecorator: (proxyReqOpts, srcReq) => {
        proxyReqOpts.headers = { ...srcReq.headers };
        return proxyReqOpts;
    },
    proxyReqPathResolver: (req) => req.originalUrl
}));

app.listen(port, () => {
    console.log(`API Gateway escuchando en http://localhost:${port}`);
});